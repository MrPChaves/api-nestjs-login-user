import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';

@Injectable()
export class UserMiddleware implements NestMiddleware {
  use(req: any, res: any, next: () => void): void {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
      throw new UnauthorizedException('Token não fornecido.');
    }

    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, 'chave-secreta'); // Substitua pela chave do login
      req.user = decoded;
      next();
    } catch (err) {
      throw new UnauthorizedException('Token inválido.');
    }
  }
}
