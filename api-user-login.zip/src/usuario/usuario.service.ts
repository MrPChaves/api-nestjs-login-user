import {
  Injectable,
  BadRequestException,
  NotFoundException,
  UnauthorizedException, // Importação adicionada
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Usuario } from './usuario.entity';
import * as nodemailer from 'nodemailer';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import * as jwt from 'jsonwebtoken'; // Importação adicionada
import * as dotenv from 'dotenv';

// Carregar variáveis do .env
dotenv.config();


@Injectable()
export class UsuarioService {
  constructor(
    @InjectRepository(Usuario)
    private readonly usuarioRepository: Repository<Usuario>,
  ) {}

    // Função para registrar um novo usuário
    async registrarUsuario(dto: { nome: string; email: string; senha: string }): Promise<string> {
  
    // Verificar duplicidade de e-mail
    const emailExistente = await this.usuarioRepository.findOne({
      where: { email: dto.email },
    });
    if (emailExistente) {
      throw new BadRequestException('E-mail já registrado.');
    }

    // Gerar token de validação aleatório
    const token = crypto.randomInt(100000, 999999).toString();

    // Hash da senha
    const senhaHash = bcrypt.hashSync(dto.senha, 10);

    // Criar e salvar o usuário com token e validade
    const novoUsuario = this.usuarioRepository.create({
      ...dto,
      senha: senhaHash,
      tokenValidacao: token,
      tokenExpiration: new Date(Date.now() + 15 * 60 * 1000), // Expiração de 15 minutos
      ativo: false,
    });

    await this.usuarioRepository.save(novoUsuario);

    // Enviar o token para o e-mail do usuário
    await this.enviarEmailToken(dto.email, dto.nome, token);

    return 'Usuário registrado com sucesso! Verifique seu e-mail para validar o cadastro.';
  }

  // Função para enviar o token por e-mail
  private async enviarEmailToken(email: string, nome: string, token: string): Promise<void> {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'patrickchavescode@gmail.com',
        pass: 'llxoalsjezjhkpvt',
      },
    });

    // Monta o título e corpo do e-mail
    const tituloEmail = `${token} é seu código de verificação da Percapta`;
    const corpoEmail = `
      <p><strong>Confirme seu endereço de e-mail</strong></p>
      <p>${nome}, você precisa concluir uma etapa rápida antes de criar sua conta na Percapta. Vamos confirmar se este é o seu endereço de e-mail.</p>
      <p><strong>Insira este código de verificação para começar a usar a Percapta:</strong></p>
      <p style="font-size: 24px; color: #2d3748;"><strong>${token}</strong></p>
      <p>Após a verificação, você se tornará um Investidor Institucional! Por aqui, estruturamos as melhores oportunidades de investimento.</p>
      <p>Abraços,<br>Equipe Percapta</p>
    `;

    await transporter.sendMail({
      from: '"Equipe Percapta" <patrickchavescode@gmail.com>',
      to: email,
      subject: tituloEmail,
      html: corpoEmail,
    });

    console.log(`E-mail enviado com sucesso para ${email}`);
  }

  // Função para listar todos os usuários
  async listarTodos(): Promise<Usuario[]> {
    return this.usuarioRepository.find();
  }

  // Função para buscar um usuário por ID
  async listarPorId(id: number): Promise<Usuario> {
    const usuario = await this.usuarioRepository.findOne({ where: { id } });
    if (!usuario) {
      throw new NotFoundException('Usuário não encontrado.');
    }
    return usuario;
  }

  // Função para atualizar um usuário
  async atualizarUsuario(id: number, dadosAtualizados: Partial<Usuario>): Promise<Usuario> {
    const usuario = await this.listarPorId(id);
    if (dadosAtualizados.senha) {
      dadosAtualizados.senha = bcrypt.hashSync(dadosAtualizados.senha, 10);
    }
    Object.assign(usuario, dadosAtualizados);
    return this.usuarioRepository.save(usuario);
  }

  // Função para deletar um usuário
  async deletarUsuario(id: number): Promise<string> {
    const resultado = await this.usuarioRepository.delete(id);
    if (resultado.affected === 0) {
      throw new NotFoundException('Usuário não encontrado.');
    }
    return 'Usuário deletado com sucesso!';
  }

  // Função para validar o token do usuário
  async validarToken(email: string, token: string): Promise<string> {
    const usuario = await this.usuarioRepository.findOne({
      where: { email, tokenValidacao: token },
    });
  
    if (!usuario || !usuario.tokenExpiration || usuario.tokenExpiration < new Date()) {
      throw new BadRequestException('Token inválido ou expirado.');
    }
  
    usuario.ativo = true;
    usuario.tokenValidacao = null; // Limpa o token
    usuario.tokenExpiration = null; // Define a expiração como `null`
    await this.usuarioRepository.save(usuario);
  
    return 'Usuário validado com sucesso!';
  }

    // Função para login do usuário
    async login(email: string, senha: string): Promise<{ token: string }> {
      const usuario = await this.usuarioRepository.findOne({ where: { email } });
    
      if (!usuario) {
        throw new UnauthorizedException('E-mail ou senha inválidos.');
      }
    
      const senhaValida = bcrypt.compareSync(senha, usuario.senha);
      if (!senhaValida) {
        throw new UnauthorizedException('E-mail ou senha inválidos.');
      }
    
      // Geração do token JWT
      const jwtSecret = process.env.JWT_SECRET;
      if (!jwtSecret) {
        throw new Error('JWT_SECRET não está definido no arquivo .env');
      }
    
      const token = jwt.sign(
        { id: usuario.id, email: usuario.email },
        jwtSecret, // Chave secreta carregada
        { expiresIn: '1h' } // Token válido por 1 hora
      );
    
      return { token }; // Retorna o token gerado
    }
  
}
