import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('usuarios')
export class Usuario {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  nome!: string;

  @Column({ unique: true })
  email!: string;

  @Column()
  senha!: string;

  @Column({ type: 'varchar', nullable: true }) // Permite valores nulos no banco
  tokenValidacao!: string | null; // Atualizei: Adicionei `null` explicitamente

  @Column({ default: false })
  ativo!: boolean;

  @Column({ type: 'timestamp', nullable: true })
  tokenExpiration?: Date | null; // Atualizado para permitir `null`


}
