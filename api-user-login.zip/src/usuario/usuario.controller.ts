import { Controller, Post, Get, Put, Delete, Param, Body, UseGuards, Req  } from '@nestjs/common';
import { UsuarioService } from './usuario.service';
import { CreateUsuarioDto } from './create-usuario.dto';
import { Usuario } from './usuario.entity';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { CustomRequest } from '../src/types/custom-requestd';
import { Request } from 'express';



@Controller('usuarios')
export class UsuarioController {
  constructor(private readonly usuarioService: UsuarioService) {}
  // Rota protegida
  @UseGuards(JwtAuthGuard)
  @Get('perfil')
  async perfil(@Req() req: CustomRequest) {
    if (!req.user) {
      throw new Error('Usuário não autenticado.');
    }

    return { id: req.user.id, email: req.user.email };
  }

  @Post('register')
  async registrarUsuario(@Body() dto: { nome: string; email: string; senha: string }): Promise<string> {
    // Atualizei este trecho para usar a função de registro com envio de token
    return this.usuarioService.registrarUsuario(dto);
  }

  @Post('validate')
  async validarToken(@Body() dto: { email: string; token: string }): Promise<string> {
    // Atualizei este trecho para validar o token do usuário
    return this.usuarioService.validarToken(dto.email, dto.token);
  }
  @Post('login')
  async login(@Body() dto: { email: string; senha: string }): Promise<{ token: string }> {
    return this.usuarioService.login(dto.email, dto.senha);
  }

  @Get()
  async listarTodos(): Promise<Usuario[]> {
    return this.usuarioService.listarTodos();
  }

  @Get(':id')
  async listarPorId(@Param('id') id: number): Promise<Usuario> {
    return this.usuarioService.listarPorId(id);
  }

  @Put(':id')
  async atualizarUsuario(
    @Param('id') id: number,
    @Body() dadosAtualizados: Partial<CreateUsuarioDto>,
  ): Promise<Usuario> {
    return this.usuarioService.atualizarUsuario(id, dadosAtualizados);
  }

  @Delete(':id')
  async deletarUsuario(@Param('id') id: number): Promise<string> {
    return this.usuarioService.deletarUsuario(id);
  }
  
}
