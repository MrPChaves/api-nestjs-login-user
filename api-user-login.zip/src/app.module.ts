import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OfertaModule } from './oferta/oferta.module';
import { ProventoModule } from './provento/provento.module';
import { TransacaoModule } from './transacao/transacao.module';
import { SharedModule } from './shared/shared.module';
import { ExtratoModule } from './extrato/extrato.module';
import { UsuarioModule } from './usuario/usuario.module';
import { CarteiraModule } from './carteira/carteira.module';
import { InvestimentoModule } from './investimento/investimento.module';
import { ImovelModule } from './imovel/imovel.module';
import { UserMiddleware } from './middleware/user.middleware';
import * as dotenv from 'dotenv';

dotenv.config(); // Carrega as variáveis do arquivo .env


@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'percapta',
      password: 'apipercapta',
      database: 'api-percapta',
      entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: true,
    }),
    OfertaModule,
    ProventoModule,
    TransacaoModule,
    SharedModule,
    ExtratoModule,
    UsuarioModule,
    CarteiraModule,
    InvestimentoModule,
    ImovelModule,
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(UserMiddleware)
      .exclude(
        { path: 'usuarios/login', method: RequestMethod.POST }, // Corrigido
        { path: 'usuarios/register', method: RequestMethod.POST } // Corrigido
      )
      .forRoutes('*');
  }
}
